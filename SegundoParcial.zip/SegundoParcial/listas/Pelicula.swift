//
//  Pelicula.swift
//  listas
//
//  Created by Alumno on 10/19/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Pelicula {
    var nombre = ""
    var disponible = ""
    var direccion = ""
    var puntuacion = ""

    init(nombre: String, disponible: String, direccion: String, puntuacion: String) {
    self.nombre = nombre
    self.disponible = disponible
    self.direccion = direccion
    self.puntuacion = puntuacion
    
    }
    
}
