//
//  ViewController.swift
//  listas
//
//  Created by Alumno on 9/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListasCinesController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cines.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaCine") as! CeldaCineController
        
        celda.lblNCine.text = cines[indexPath.row].nombre
        celda.lblAbierto.text = cines [indexPath.row].horario
        celda.lblDireccion.text = cines [indexPath.row].direccion
        celda.lblPuntuacion.text = cines [indexPath.row].calif
        return celda
    }
    
    @IBOutlet var tvCines: UITableView!
    
    @IBOutlet weak var tvPeliculas: UITableView!
    
    var cines : [Cine] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Cines"
        
        cines.append(Cine(nombre: "Cinemark", horario: "Abierto", direccion: "Kino", calif: "9.5" ))
        
        cines.append(Cine(nombre: "AMC", horario: "Abierto", direccion: "Metrocenro", calif: "10" ))
        
        cines.append(Cine(nombre: "Cinemagia", horario: "Abierto", direccion: "Colosio", calif: "8.5" ))
        
        cines.append(Cine(nombre: "Cinemex", horario: "Abierto", direccion: "Dila", calif: "7.5" ))
        
        cines.append(Cine(nombre: "Cinepolis", horario: "Abierto", direccion: "Solidaridad", calif: "6.5" ))
        
            }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! ListasPeliculasController
        destino.peliculas = cines[tvCines.indexPathForSelectedRow!.row].
        
    }
    
}

