//
//  ViewController.swift
//  listas
//
//  Created by Alumno on 9/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListasCinesController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cines.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaCine") as! CeldaCineController
        
        celda.imgCine.image = UIImage(named: cines[indexPath.row].foto)
        
        
        celda.lblNCine.text = cines[indexPath.row].nombre
        celda.lblAbierto.text = cines [indexPath.row].horario
        celda.lblDireccion.text = cines [indexPath.row].direccion
        celda.lblPuntuacion.text = cines [indexPath.row].calif
        return celda
    }
    
    @IBOutlet var tvCines: UITableView!
    
    
    
    var cines : [Cine] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Cines"
        
        cines.append(Cine(nombre: "Cinemark", horario: "Abierto", direccion: "Kino", calif: "9.5", foto: "fondocine", peliculas:[
            Pelicula(nombre: "007", disponible: "Lleno", direccion: " Joji Fukunaga", puntuacion: "9.5", foto: "007"),
            Pelicula(nombre: "Venom", disponible: "Lleno", direccion: "Peter Jackson", puntuacion: "8.5", foto: "venom"),
            Pelicula(nombre: "It", disponible: "Disponible", direccion: "Andy Mscietti", puntuacion: "4.5", foto: "eso"),
            Pelicula(nombre: "Scream", disponible: "Lleno", direccion: "Fukunaga", puntuacion: "6.5", foto: "scream"),
            Pelicula(nombre: "Dune", disponible: "Disponible", direccion: "Villeneve", puntuacion: "9.5", foto: "dune")
        ]))
        
        cines.append(Cine(nombre: "Cinemagia", horario: "Abierto", direccion: "Quiroga", calif: "5.5",foto: "amc", peliculas:[
            Pelicula(nombre: "Godzilla", disponible: "Lleno", direccion: "Fukunaga", puntuacion: "10", foto: "godzilla"),
            Pelicula(nombre: "Star Wars", disponible: "Lleno", direccion: "Peter Jackson", puntuacion: "8.5", foto: "sw"),
            Pelicula(nombre: "It", disponible: "Disponible", direccion: "Andy Mscietti", puntuacion: "4.5", foto: "eso"),
            Pelicula(nombre: "Django", disponible: "Lleno", direccion: "Tarantino", puntuacion: "2.5", foto: "django"),
            Pelicula(nombre: "El Señor de los Anillos", disponible: "Lleno", direccion: "Peter Jackson", puntuacion: "9.5", foto: "lotr")
        ]))
        
        cines.append(Cine(nombre: "AMC", horario: "Abierto", direccion: "Colosio", calif: "6.5", foto: "fondoproyector", peliculas:[
            Pelicula(nombre: "Batman", disponible: "Lleno", direccion: "Matt Reeves", puntuacion: "3.5", foto: "batman"),
            Pelicula(nombre: "Black Adam", disponible: "Lleno", direccion: "Peter Jackson", puntuacion: "6.5", foto: "black"),
            Pelicula(nombre: "Flash", disponible: "Disponible", direccion: "Andy Muscietti", puntuacion: "4.5", foto: "flash"),
            Pelicula(nombre: "Superman", disponible: "Lleno", direccion: "Bryan Singer", puntuacion: "6.5", foto: "superman"),
            Pelicula(nombre: "Spider-Man", disponible: "Disponible", direccion: "Villeneve", puntuacion: "9.5", foto: "spider")
        ]))
        
        cines.append(Cine(nombre: "Cinepolis", horario: "Abierto", direccion: "Kino", calif: "9.5", foto: "fondobutacas", peliculas:[
            Pelicula(nombre: "Viernes 13", disponible: "Lleno", direccion: "Fukunaga", puntuacion: "9.5", foto: "jason"),
            Pelicula(nombre: "Freddy vs. Jason", disponible: "Lleno", direccion: "Peter Jackson", puntuacion: "8.5", foto: "fvj"),
            Pelicula(nombre: "It", disponible: "Disponible", direccion: "Andy Muscietti", puntuacion: "4.5", foto: "eso"),
            Pelicula(nombre: "Duro de Matar", disponible: "Lleno", direccion: "Craven", puntuacion: "6.5", foto: "duro"),
            Pelicula(nombre: "Rambo", disponible: "Disponible", direccion: "Villeneve", puntuacion: "9.5", foto: "rambo")
        ]))
        
        cines.append(Cine(nombre: "Cinema 94", horario: "Abierto", direccion: "Blvd. Rodriguez", calif: "10", foto: "fondosala", peliculas:[
            Pelicula(nombre: "The Wind Rises", disponible: "Lleno", direccion: "Fukunaga", puntuacion: "10", foto: "twr"),
            Pelicula(nombre: "Evangelion", disponible: "Lleno", direccion: "Anno", puntuacion: "8.5", foto: "eva"),
            Pelicula(nombre: "Your Name", disponible: "Disponible", direccion: "Andy Muscietti", puntuacion: "7.5", foto: "yn"),
            Pelicula(nombre: "Jagten", disponible: "Lleno", direccion: "Craven", puntuacion: "8.5", foto: "jagten"),
            Pelicula(nombre: "Druk", disponible: "Lleno", direccion: "Villeneve", puntuacion: "4.5", foto: "druk")
        ]))
        
        
        
        
        
        
        
        }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! ListasPeliculasController
        destino.peliculas = cines[tvCines.indexPathForSelectedRow!.row].peliculas
        
    }
    
}

