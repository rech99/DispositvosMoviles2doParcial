//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/15/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation


class Cine {
    var nombre = ""
    var horario = ""
    var direccion = ""
    var calif = ""
    var foto = ""
    
    var peliculas : [Pelicula] = []
    

    init(nombre: String, horario: String, direccion: String, calif: String, foto:String, peliculas: [Pelicula]) {
    self.nombre = nombre
    self.horario = horario
    self.direccion = direccion
    self.calif = calif
    self.peliculas = peliculas
    self.foto = foto
        
    
        
    
    }
        
    
    
    
}
