//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit




class ListasPeliculasController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var peliculas : [Pelicula] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peliculas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaPeli") as! CeldaPeliculasController
        
        celda.lblNombre.text = peliculas[indexPath.row].nombre
        celda.lblDisponible.text = peliculas [indexPath.row].disponible
        celda.lblDireccion.text = peliculas [indexPath.row].direccion
        celda.lblPuntuacion.text = peliculas [indexPath.row].puntuacion
        return celda
  
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Cartelera"
        
        
        peliculas.append(Pelicula(nombre: "Venom", disponible: "Disponible", direccion: "Kino", puntuacion:  "7.5" ))
        peliculas.append(Pelicula(nombre: "007", disponible: "Lleno", direccion: "Kino", puntuacion:  "6.5" ))
        peliculas.append(Pelicula(nombre: "Halloween", disponible: "Disponible", direccion: "Kino", puntuacion:  "9.5" ))
        peliculas.append(Pelicula(nombre: "Scream", disponible: "Lleno", direccion: "Kino", puntuacion:  "5.5" ))
        peliculas.append(Pelicula(nombre: "Avengers", disponible: "Disponible", direccion: "Kino", puntuacion:  "9.5" ))
        
        
    }
    
        
}

