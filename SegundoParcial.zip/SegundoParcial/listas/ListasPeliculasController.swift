//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit




class ListasPeliculasController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    var peliculas : [Pelicula] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peliculas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "CeldasPelis") as! CeldaPeliculasController
        
        celda.imgPelicula.image = UIImage (named: peliculas[indexPath.row].foto)
        celda.lblNombre.text = peliculas[indexPath.row].nombre
        celda.lblDisponible.text = peliculas [indexPath.row].disponible
        celda.lblDireccion.text = peliculas [indexPath.row].direccion
        celda.lblPuntuacion.text = peliculas [indexPath.row].puntuacion
        return celda
  
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Cartelera"
        
        
        
            }
    
        
}

