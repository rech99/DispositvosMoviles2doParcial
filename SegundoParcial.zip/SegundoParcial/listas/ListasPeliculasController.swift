//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class ListasPeliculasController : UIViewController  {
    
    var cine : Cine = Cine(nombre: "", horario: "", direccion: "", calif: "")
   
    override func viewDidLoad() {
        
        self.title = cine.nombre
    }
    
        
}

