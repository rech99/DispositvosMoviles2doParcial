//
//  CeldaCineController.swift
//  listas
//
//  Created by Alumno on 10/15/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaCineController :UITableViewCell {
    
    
 
    @IBOutlet weak var imgCine: UIImageView!
    @IBOutlet weak var lblNCine: UILabel!
    @IBOutlet weak var lblAbierto: UILabel!
    @IBOutlet weak var lblDireccion: UILabel!
    @IBOutlet weak var lblPuntuacion: UILabel!
}
