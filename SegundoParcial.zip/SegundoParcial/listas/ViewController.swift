//
//  ViewController.swift
//  listas
//
//  Created by Alumno on 9/28/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let nombre = ["Venom", "007", "Scream", "Halloween", "Godzilla"]
    let  horario = ["12:00", "7:00", "9:00", "10:30", "12:30"]
    let fecha = ["31 de octubre", "1 de noviembre", "2 de noviembre", "3 de diceimbre", "4 de diciembre"]
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 79
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nombre.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaPelicula") as! CeldaPeliculasController
        
        celda.lblNombre.text = nombre[indexPath.row]
        celda.lblFecha.text = fecha [indexPath.row]
        celda.lblHorario.text = horario[indexPath.row]
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaPelicula") as! CeldaCineController
        
        celda.lblNombre.text = nombres[indexPath.row]
        celda.lblFecha.text = promedios[indexPath.row]
        celda.lblHorario.text = matriculas[indexPath.row]
        
        return celda
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func DoTapVolver(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

