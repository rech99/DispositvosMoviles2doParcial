//
//  CeldaPeliculasController.swift
//  listas
//
//  Created by Alumno on 10/12/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaPeliculasController : UITableViewCell{
    
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblHorario: UILabel!
    @IBOutlet weak var lblFecha: UILabel!
    @IBOutlet weak var lblDisponible: UILabel!
}
