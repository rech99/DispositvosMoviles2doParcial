//
//  CeldaPeliculasController.swift
//  listas
//
//  Created by Alumno on 10/12/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaPeliculasController : UITableViewCell{
    
    
    @IBOutlet weak var imgPelicula: UIImageView!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblDireccion: UILabel!
    @IBOutlet weak var lblDisponible: UILabel!
    
    @IBOutlet weak var lblPuntuacion: UILabel!
    
}
