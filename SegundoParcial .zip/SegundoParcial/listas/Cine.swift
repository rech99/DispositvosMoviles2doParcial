//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/15/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation


class Cine {
    var nombre = ""
    var horario = ""
    var direccion = ""
    var calif = ""

    init(nombre: String, horario: String, direccion: String, calif: String) {
    self.nombre = nombre
    self.horario = horario
    self.direccion = direccion
    self.calif = calif
    
    }
    
}
