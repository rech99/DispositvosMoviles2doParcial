//
//  Cine.swift
//  listas
//
//  Created by Alumno on 10/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Pelicula {
    var nombre = ""
    var horario = ""
    var fecha = ""
    var dispon = ""

    init(nombre: String, horario: String, fecha: String, dispon: String) {
    self.nombre = nombre
    self.horario = horario
    self.fecha = fecha
    self.dispon = dispon
    
    }
    
}

